import React from "react";

function RegisteredSuccess() {
  return <div>Registered Successfully. Please verify your account from the mail sent to your email id</div>;
}

export default RegisteredSuccess;
