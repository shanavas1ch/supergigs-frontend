export const bannerContent = {
  banner1: {
    mainText:
      "The World's Agile Talent Platform that perfectly fits your business needs.",
    subText:
      " Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.",
  },
  banner2: {
    mainText:
      "Why Slog In A 9-5 Job When You Can Earn 5X More Through Freelancing!",
    subText:
      "Let's experiment with a different color background for the hero banner",
  },
  banner3: {
    mainText:
      "Become A SuperLancer Today!",
    subText:
      "Inspire upcoming talent and enjoy rewards as we grow together as a community.",
  },
};
