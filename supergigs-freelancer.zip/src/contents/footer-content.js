export const footerContent = {
  content: [
    {
      name: "For Freelancer",
      footerList: [
        "Developers",
        "Finance Experts",
        "Project Managers",
        "Product Managers",
        "Sofwtare Engineering",
        "Engineering Management",
        "Developer Operations(DevOps)",
        "Data Analytics",
      ],
    },
    {
      name: "For Clients",
      footerList: [
        "Developers",
        "Finance Experts",
        "Project Managers",
        "Product Managers",
        "Sofwtare Engineering",
        "Engineering Management",
        "Developer Operations(DevOps)",
        "Data Analytics",
      ],
    },
    {
      name: "Resources",
      footerList: ["Blog", "Community", "Forum", "Feedback"],
    },
    {
      name: "Company",
      footerList: [
        "About Us",
        "Career",
        "Contact Us",
        "Terms of Service",
        "Privacy Policy ",
        "Cookie ",
        "Settings",
      ],
    },
  ],
};
