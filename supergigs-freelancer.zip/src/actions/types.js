export const SAMPLE = "SAMPLE";
export const DATA = "DATA";
